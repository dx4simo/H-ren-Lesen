# tools/csv_to_questions_json.py
import csv, json, sys, pathlib

SRC = pathlib.Path("game/questions.csv")
DST = pathlib.Path("game/questions.json")

BOOL = {"TRUE": True, "FALSE": False, "": None, None: None}

def to_bool(x):
    if x is None:
        return None
    return BOOL.get(str(x).strip().upper(), None)

def main():
    if not SRC.exists():
        print(f"[ERR] CSV not found: {SRC}", file=sys.stderr)
        sys.exit(1)

    items = []
    with SRC.open("r", encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            # اجمع الاختيارات الموجودة فقط
            options = []
            for i in range(1, 7):
                t = row.get(f"opt{i}_text", "") or ""
                c = row.get(f"opt{i}_correct", "")
                if t.strip() == "" and str(c).strip() == "":
                    continue
                options.append({
                    "text": t,
                    "correct": bool(to_bool(c)),
                })

            item = {
                "id": row.get("id", "").strip(),
                "question": row.get("question", "").strip(),
                "options": options,
                "points": int(row.get("points", "0") or 0),
                "head_correct": bool(to_bool(row.get("head_correct", "FALSE"))),
                "head_points": int(row.get("head_points", "0") or 0),
                "bg": (row.get("bg", "") or "").strip() or None
            }

            if not item["id"]:
                print("[WARN] Skipping a row without id", file=sys.stderr)
                continue
            if not item["question"]:
                print(f"[WARN] {item['id']}: empty question", file=sys.stderr)
            if not item["options"]:
                print(f"[WARN] {item['id']}: no options", file=sys.stderr)

            items.append(item)

    DST.parent.mkdir(parents=True, exist_ok=True)
    with DST.open("w", encoding="utf-8") as f:
        json.dump(items, f, ensure_ascii=False, indent=2)

    print(f"[OK] Wrote {DST} ({len(items)} items)")

if __name__ == "__main__":
    main()
